module1 contains the pet resource generation on basis of ami_id

module2 contains localfile path.